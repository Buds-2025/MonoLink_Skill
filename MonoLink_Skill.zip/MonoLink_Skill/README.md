# MonoLink Skill

这是一个面向 OpenClaw / AgentSkills 体系的图片生成技能2.0版，名称为MonoLink Skill，用于稳定生成黑白诗性拼贴摄影风格图像。

和1.0版相比，2.0版的重点调整是：

1．把“关系优先”写成硬规则。
2．把边界从分割线升级为“意义发生区”。
3．显著强化组合、延伸、相似、对照、递进五种关系的执行标准。
4．增加失败判定标准，避免只生成表面风格相似、但关系薄弱的图片。

## 适合做什么
- 黑白拼贴摄影风格图片
- 摄影书内页感版式
- 左右双联画、上下双联画、三联画、多宫格
- 人物、飞鸟、树枝、烟雾、道路、沙漠、海面、车辆、火焰等意象创作
- 需要“组合、延伸、相似、对照、递进”等强关系的作品

## 目录结构
- `SKILL.md`：技能主文件，包含元数据与操作说明
- `resources/style-analysis.md`：风格分析
- `resources/composition-grammar.md`：构图与拼接语法
- `resources/prompt-template.md`：提示词模板1.0与2.0
- `resources/relation-first-rules.md`：关系优先规则
- `examples/desert_person_car.md`：沙漠里的人和车示例
- `examples/more_examples.md`：更多主题示例
- `examples/flame_head.md`：火焰头示例
- `examples/traffic_and_ants.md`：城市车流与蚂蚁路径示例

## 安装方式
根据 OpenClaw 官方文档，skill本质上是一个包含 `SKILL.md` 的目录，可放在工作区的 `skills` 目录中。

可选位置示例：
- `~/.openclaw/skills/MonoLink_Skill`
- `<workspace>/skills/MonoLink_Skill`

安装后新开会话，或重启网关，让系统重新加载技能。

## 使用建议
如果用户只给出主题，例如：
- “沙漠里的人和车”
- “海边的路灯和飞鸟”
- “城市里的车流和蚂蚁路径”
- “人的头部是火焰”

调用本技能时，应先判断最强主关系，再决定左右拼接、上下拼接或多联画，最后生成完整提示词或直接出图。
